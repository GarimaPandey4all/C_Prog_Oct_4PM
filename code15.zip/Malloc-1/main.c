#include <stdio.h>
#include <stdlib.h>

/*
    malloc()

    malloc stands for memory allocation

    The malloc() function reserves the block of memory of the specified number of bytes.
    And, it returns a pointer of void which can be casted into pointers of any type/form.

    Syntax:

    ptr = (castType *)malloc(size);

*/

int main()
{
    int size;
    char *text = NULL;

    printf("Enter limit of the text:");
    scanf("%d", &size);

    //Memory Allocation
    text = (char *)malloc(size * sizeof(char)); // char - 1 byte; 3 * 1 = 4 bytes

    if(text != NULL)
    {
        printf("Enter some text:");
        scanf(" "); // Brain Mentors
        gets(text);

        printf("Inputted text is: %s", text);
    }

    //Memory Deallocation
    free(text);
    text = NULL;

    return 0;
}
