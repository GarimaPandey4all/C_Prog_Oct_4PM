#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, j;

    for(i = 97; i <= 101; i++)
    {
        for(j = 97; j <= 101; j++)
        {
            printf("%c", j);
            //printf("%c", i);
        }
        printf("\n");
    }

    return 0;
}
