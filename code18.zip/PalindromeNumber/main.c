#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, r, sum = 0, temp;

    printf("Enter any number to check whether the given number is palindrome or not:");
    scanf("%d", &n);

    temp = n;

    // n = 121 = 12

    while(n > 0)
    {
        r = n % 10; // r = 121 % 10 = 1 // 12 % 10 = 2 // 1 % 10 = 1
        sum = sum * 10 + r; // sum = 0 * 10 + 1 = 1 // 1 * 10 + 2 = 12 // 12 * 10 + 1 = 121
        n = n / 10; // n = 121 / 10 = 12 // 12 / 10 = 1 // 1 / 10 = 0
    }

    n = temp;

    if(n == sum)
        printf("Palindrome Number");
    else
        printf("Not a Palindrome Number");

    return 0;
}
