#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, r, reverse = 0;

    printf("Enter any number:");
    scanf("%d", &n);

    // n = 121 = 121

    while(n > 0)
    {
        r = n % 10; // r = 121 % 10 = 1 // 12 % 10 = 2 // 1 % 10 = 1
        reverse = reverse * 10 + r; // reverse = 0 * 10 + 1 = 1 // 1 * 10 + 2 = 12 // 12 * 10 + 1 = 121
        n = n / 10; // n = 121 / 10 = 12 // 12 / 10 = 1 // 1 / 10 = 0
    }

    printf("Reverse Number is: %d", reverse);

    return 0;
}
