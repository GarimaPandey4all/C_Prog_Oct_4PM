#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, r, sum = 0;

    printf("Enter any number:");
    scanf("%d", &n);

    // n = 121 = 1 + 2 + 1 = 4

    while(n > 0)
    {
        r = n % 10; // r = 121 % 10 = 1 // r = 2 // r = 1
        sum = sum + r; // 0 + 1 = 1 // 1 + 2 = 3 // 3 + 1 = 4
        n = n / 10; // n = 12// 1 // 0
    }

    printf("Sum of Digits is: %d", sum);

    return 0;
}
