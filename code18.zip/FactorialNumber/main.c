#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, fact = 1;

    printf("Please enter any number to find the factorial:");
    scanf("%d", &n);

    for(i = 1; i <= n; i++)
    {
        fact *= i; // fact = fact * i;
    }

    printf("Factorial of %d is: %d", n, fact);

    return 0;
}
