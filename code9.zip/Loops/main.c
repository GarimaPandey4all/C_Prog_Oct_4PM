#include <stdio.h>
#include <stdlib.h>

/*
    1. for loop

    for(initalization; condition; Increment/Decrement)
    for(i = 1; i <= 10; i++)
    {
        //block of for loop
    }

    2. While loop

    int i = 1; // initialization

    while(i <= 10) // condition
    {
        //block of while loop
        increment/decrement
    }

    3. Do-while loop

    int i = 1; // initialization

    do
    {
        //block of do-while loop
        increment/decrement

    }while(i <= 10);

*/

int main()
{
    int i;

    for(i = 1; i <= 10; i++)
    {
        printf("Hello World\n");
    }

    return 0;
}
