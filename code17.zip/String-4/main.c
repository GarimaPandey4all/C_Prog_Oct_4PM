#include <stdio.h>
#include <stdlib.h>

int main()
{
    char firstName[10];
    char lastName[10];

    printf("Enter your firstname:");
    gets(firstName);

    printf("Enter your lastname:");
    gets(lastName);

    printf("Your fullname is: %s", strcat(firstName, lastName));

    return 0;
}
