#include <stdio.h>
#include <stdlib.h>

/*
    String Compare:

    0, 1, -1

    string 1 == string 2 = 0

    string 1(a) ; string 2(b) : 1

    string 1(b) ; string 2(a) : -1

*/

int main()
{
    char str1[10];
    char str2[10];

    printf("Enter String 1:");
    gets(str1);

    printf("Enter String 1:");
    gets(str2);

    if(strcmp(str1, str2) == 0)
        printf("Both the strings are same");
    else
        printf("Strings are not same");

    return 0;
}
