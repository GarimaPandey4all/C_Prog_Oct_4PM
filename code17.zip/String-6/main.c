#include <stdio.h>
#include <stdlib.h>

int main()
{
    char str[10];

    printf("Enter any string:");
    gets(str);

    printf("Lowercase is: %s\n", strlwr(str));

    printf("Uppercase is: %s", strupr(str));

    return 0;
}
