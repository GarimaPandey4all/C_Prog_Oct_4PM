#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, temp;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    printf("Before swapping the value of a=%d and b=%d\n", a, b);

    temp = a;
    a = b;
    b = temp;

    printf("After swapping the value of a=%d and b=%d\n", a, b);

    return 0;
}
