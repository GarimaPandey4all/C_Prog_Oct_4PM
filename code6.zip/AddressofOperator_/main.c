#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 10;

    printf("Value of a: %d\n", a);

    printf("Value of a: %d\n", &a);

    return 0;
}
