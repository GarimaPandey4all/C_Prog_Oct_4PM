#include <stdio.h>
#include <stdlib.h>

//2. Function with Arguments and without return value.

void Add(int, int); //void - empty

int main()
{
    //Function Calling

    int a, b;

    Add(a, b); // Actual Arguments/ Arguments

    return 0;
}

//Function Definition
void Add(int a, int b) //Function prototype // Formal Arguments/Parameters
{
    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    printf("Addition is: %d\n", (a + b));
}

