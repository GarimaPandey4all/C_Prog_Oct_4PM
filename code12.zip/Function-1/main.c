#include <stdio.h>
#include <stdlib.h>

/*
    Function has four types:

    1. Function without Arguments and without return value.
    2. Function with Arguments and without return value.
    3. Function without Arguments and with return value.
    4. Function with Arguments and with return value.
*/

//1. Function without Arguments and without return value.

//Function Declaration
void Add(); //void - empty

int main()
{
    //Function Calling
    Add();
    Add();
    Add();

    return 0;
}

//Function Definition
void Add()
{
    int a, b;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    printf("Addition is: %d\n", (a + b));
}

