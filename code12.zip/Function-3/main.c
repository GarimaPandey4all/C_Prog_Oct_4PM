#include <stdio.h>
#include <stdlib.h>

//3. Function without Arguments and with return value.

int Add(); //void - empty

int main()
{
    int result;

    //Function Calling
    result = Add();

    printf("Addition is: %d", result);

    return 0;
}

//Function Definition
int Add()
{
    int a, b;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    //printf("Addition is: %d\n", (a + b));

    return (a + b);
}

