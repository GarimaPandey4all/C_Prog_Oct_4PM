#include <stdio.h>
#include <stdlib.h>

//4. Function with Arguments and with return value.

int Add(int, int);

int main()
{
    int a, b, result;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    result = Add(a, b);

    printf("Addition is: %d", result);

    return 0;
}

int Add(int a, int b)
{
    //printf("Addition is: %d\n", (a + b));

    return (a + b);

    return 0;
}

