#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x, y;

    printf("Enter any value for a and b:");
    scanf("%d %d", &x, &y);

    printf("Before swapping the value of x=%d and y=%d\n", x, y);

    swap(&x, &y);

    printf("After swapping the value of x=%d and y=%d", x, y);

    return 0;
}

void swap(int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}
