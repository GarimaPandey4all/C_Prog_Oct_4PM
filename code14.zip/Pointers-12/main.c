#include <stdio.h>
#include <stdlib.h>

//12 bytes

union Date
{
    int day;
    int month;
    int year;
}date, *pdate;

//union Date date, date1, date2;

int main()
{
    //union Date date, date1, date2;

    pdate = &date;

    pdate->day = 1;

    printf("Day = %d\n", pdate->day);

    pdate->month = 10;

    printf("Month = %d\n", pdate->month);

    pdate->year = 2020;

    printf("Year = %d\n", pdate->year);
    /*

    printf("Day = %d, Month = %d and Year= %d\n", date.day, date.month, date.year);

    printf("Day = %d, Month = %d and Year= %d", date1.day, date1.month, date1.year);

    */

    return 0;
}
