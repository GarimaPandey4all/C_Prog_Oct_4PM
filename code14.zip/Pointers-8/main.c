#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i = 10;
    char z = 'A';
    float j = 2.45f;

    void *ptr; // void pointer

    ptr = &i;
    printf("I is: %d\n", *(int *)ptr);

    ptr = &z;
    printf("I is: %c\n", *(char *)ptr);

    ptr = &j;
    printf("I is: %f\n", *(float *)ptr);

    return 0;
}
