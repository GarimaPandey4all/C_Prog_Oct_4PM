#include <stdio.h>
#include <stdlib.h>

int main()
{
    //Pointer to a Constant and constant pointer

    const int value = 10;
    int number = 20;

    const int *const pvalue = &value;
    // pointer to a constant // value can't be changed
    // Constant Pointer // address can't be changed

    //*pvalue = 30; // error

    //pvalue = &number; //error

    //value = 40; // error

    printf("value is: %d\n", *pvalue);

    printf("Value is: %d\n", value);

    return 0;
}
