#include <stdio.h>
#include <stdlib.h>

//12 bytes

union Date
{
    int day;
    int month;
    int year;
}date, date1;

//union Date date, date1, date2;

int main()
{
    //union Date date, date1, date2;

    date.day = 1;

    printf("Day = %d\n", date.day);

    date.month = 10;

    printf("Month = %d\n", date.month);

    date.year = 2020;

    printf("Year = %d\n", date.year);

    date1.day = 2;

    printf("Day = %d\n", date1.day);

    date1.month = 10;

    printf("Month = %d\n", date1.month);

    date1.year = 2020;

    printf("Year = %d\n", date1.year);

    /*

    printf("Day = %d, Month = %d and Year= %d\n", date.day, date.month, date.year);

    printf("Day = %d, Month = %d and Year= %d", date1.day, date1.month, date1.year);

    */

    return 0;
}
