#include <stdio.h>
#include <stdlib.h>

//12 bytes

struct Date
{
    int day;
    int month;
    int year;
}date, *pdate;

//struct Date date, date1, date2;

int main()
{
    //struct Date date, date1, date2;

    pdate = &date;

    (*pdate).day = 1;
    (*pdate).month = 10;
    pdate->year = 2020;

    printf("Day = %d, Month = %d and Year= %d\n", pdate->day, pdate->month, (*pdate).year);

    return 0;
}
