#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 5, b = 7;

    printf("Bitwise AND Operator:%d\n", (a & b)); // 5
    printf("Bitwise OR Operator:%d\n", (a | b)); // 7
    printf("Bitwise Ones Complement Operator:%d\n", (~a)); // 250
    printf("Bitwise X-OR Operator:%d\n", (a ^ b)); // 2
    printf("Bitwise Left Shift Operator:%d\n", (a<<4)); // 10, 80
    printf("Bitwise Right Shift Operator:%d\n", (a>>4)); // 2, 0

    return 0;
}
