#include <stdio.h>
#include <stdlib.h>

int main()
{
    int value = 10;

    int *pvalue = &value;

    printf("Value is: %d\n", *pvalue); // 10 // * - Dereference Operator - data

    printf("Value is: %d\n", pvalue); // address of value variable

    printf("Value is: %d\n", &pvalue); // address of pointer variable

    return 0;
}
