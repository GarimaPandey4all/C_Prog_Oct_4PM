#include <stdio.h>
#include <stdlib.h>

int main()
{
    int count = 10, x;

    int *pcount = &count;

    x = *pcount;

    printf("X is: %d\n", x);

    printf("count is: %d\n", count);

    return 0;
}
