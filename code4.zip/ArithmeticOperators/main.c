#include <stdio.h>
#include <stdlib.h>

/*

    Operator - Symbol

    Expression - (a + b); // a , b = Operands; +  ->Operator
*/

int main()
{
    int a, b;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    printf("Addition is: %d\n", (a + b));
    printf("Subraction is: %d\n", (a - b));
    printf("Multiplication is: %d\n", (a * b));
    printf("Division is: %d\n", (a / b));
    printf("Modulus is: %d\n", (a % b)); // 3 % 5 = 3

    //Pre and Post Increment // a = 4,  b= 5
    printf("Pre-Increment is:%d\n", (++a)); // a = 4 + 1 = 5
    printf("Post-Increment is:%d\n", (a++)); // a = 5
    printf("A is: %d\n", a); // a = 6

    //Pre and Post Decrement
    printf("Pre-Decrement is:%d\n", (--b)); // b = 5 - 1 = 4
    printf("Post-Decrement is:%d\n", (b--)); // b = 4
    printf("B is: %d\n", b); // b = 3

    return 0;
}
