#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    printf("Logical AND Operator: %d\n", ((a > b) && (b < 10)));
    printf("Logical OR Operator: %d\n", ((a > b) || (b < 10)));
    printf("Logical Not Operator: %d\n", (!(a > b) && (b < 10)));

    return 0;
}
