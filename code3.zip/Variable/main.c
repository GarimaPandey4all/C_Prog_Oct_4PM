#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 10;
    const int b = 40;

    a = 50;

    printf("A is: %d", a);

    a = 90;

    //b = 80; // error

    return 0;
}
