#include <stdio.h>
#include <stdlib.h>
#define MONTHS 12

int main()
{
    printf("Total Months in a year: %d", MONTHS);

    return 0;
}
