#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 10;
    char ch = 'M';
    float b = 56.78f;

    printf("Int is : %d\n", a); // "\n" - new line
    printf("char is: %c\n", ch);
    printf("float is: %.2f\n", b);

    return 0;
}
