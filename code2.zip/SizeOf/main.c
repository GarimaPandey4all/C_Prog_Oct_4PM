#include <stdio.h>
#include <stdlib.h>

int main()
{
    //sizeof()

    int a = 10;

    printf("Size of Int is: %d\n", sizeof(int));
    printf("Size of Int is: %d\n", sizeof(a));
    printf("Size of Char is: %d\n", sizeof(char));
    printf("Size of Float is: %d\n", sizeof(float));
    printf("Size of Double is: %d\n", sizeof(double));
    printf("Size of Long Double is: %d\n", sizeof(long double));

    return 0;
}
