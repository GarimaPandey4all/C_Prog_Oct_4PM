#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *fp = NULL;

    int length;

    fp = fopen("file.txt", "r");

    if(fp == NULL)
    {
        printf("Error in opening file");
        exit(0);
    }

    //Moving pointer to end
    fseek(fp, 0, SEEK_END);

    //tell position of pointer
    length = ftell(fp); // 22

    printf("Total size of file is: %d", length);

    fclose(fp);
    fp = NULL;

    return 0;
}
