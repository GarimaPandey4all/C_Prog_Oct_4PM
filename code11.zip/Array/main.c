#include <stdio.h>
#include <stdlib.h>

//Array: It is a collection of similar types of data. It is a homogeneous mixture.
//It contains multiple values in a single variable.
//Contiguous Memory Allocation

int main()
{
    int arr[5] = {10, 20, 30, 40, 50}; // Array Declaration and Initialization
    //[]- Sqaure bracket/ Subscript operator // 5 - size of the array
    int i;

    /*
    printf("First Value: %d\n", arr[0]);
    printf("Second Value: %d\n", arr[1]);
    printf("Third Value: %d\n", arr[2]);
    printf("Fourth Value: %d\n", arr[3]);
    printf("Fifth Value: %d\n", arr[4]);
    */
    printf("Values in an Array are:\n");
    for(i = 0; i < 5; i++)
    {
        printf("%d\t", arr[i]);
    }

    return 0;
}
