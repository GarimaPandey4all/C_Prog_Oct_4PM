#include <stdio.h>
#include <stdlib.h>

int main()
{
    int arr[5], i;

    printf("Enter values in an array:");
    for(i = 0; i < 5; i++)
    {
        scanf("%d", &arr[i]);
    }

    printf("Values in an array are:\n");
    for(i = 0; i < 5; i++)
    {
        printf("%d\t", arr[i]);
    }

    return 0;
}
