#include <stdio.h>
#include <stdlib.h>

int main()
{
    //Calculator
    //Switch - Menu Driven Program

    int a, b;
    int choice;
    //char ch;

//for(;;){
while(1) // loop - repeation // infinite // 1 - true
{

    printf("\n\nPress 1: Addition\n");
    printf("Press 2: Subtraction\n");
    printf("Press 3: Multiplication\n");
    printf("Press 4: Division\n");
    printf("Press 5: Exit\n");
    printf("\n\nEnter your choice:");
    scanf("%d", &choice);
    //scanf("%c", &ch);

    switch(choice)
    {
    //case '+':
    case 1:
        printf("Enter any value for a and b:");
        scanf("%d %d", &a, &b);
        printf("Addition:%d\n", (a + b));
        break;

    //case '-':
    case 2:
        printf("Enter any value for a and b:");
        scanf("%d %d", &a, &b);
        printf("Subtraction:%d\n", (a - b));
        break;

    //case '*':
    case 3:
        printf("Enter any value for a and b:");
        scanf("%d %d", &a, &b);
        printf("Multiplication:%d\n", (a * b));
        break;

    //case '/':
    case 4:
        printf("Enter any value for a and b:");
        scanf("%d %d", &a, &b);
        printf("Division:%d\n", (a / b));
        break;

    //case 'e':
    case 5:
        exit(0); // exit()- arguments

    default:
        printf("Invalid Choice");
        break;
    }
}

    //printf("Outside Switch");

    return 0;
}
