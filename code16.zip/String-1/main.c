#include <stdio.h>
#include <stdlib.h>

//String: it is a collection of characters or more than one character is called the string.

//Character of Arrays is called string in c.


int main()
{
    char name[10];

    printf("Enter your name:");
    //scanf("%s", &name);
    gets(name);

    //puts(name);
    printf("Your name is: %s", name);

    return 0;
}
