#include <stdio.h>
#include <stdlib.h>

int main()
{
    char str1[10];
    char str2[10];

    printf("Enter String - 1:");
    gets(str1);

    printf("Enter String - 2:");
    gets(str2);

    printf("String - 1 copying in String - 2: %s\n", strcpy(str2, str1));

    printf("String - 1 copying in Kullu: %s\n", strcpy(str2, "Kullu"));

    printf("String - 2 copying in String - 1: %s\n", strcpy(str1, str2));

    return 0;
}
