#include <stdio.h>
#include <stdlib.h>

int main()
{
    char *str;

    str = (char *)malloc(15); // 15 bytes

    // string copy
    strcpy(str, "Jason");

    printf("String = %s and Address = %u\n", str, str);

    //Reallocation Memory
    str = realloc(str, 25);

    //String Concatenation/Joining
    strcat(str, ".com");

    printf("String = %s and Address = %u\n", str, str);

    free(str);
    str = NULL;

    return 0;
}
